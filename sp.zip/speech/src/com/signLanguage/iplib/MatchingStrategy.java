package com.signLanguage.iplib;

/**
 * RATIO CONSTANT
 */
public enum MatchingStrategy {
    RATIO_TEST
}
