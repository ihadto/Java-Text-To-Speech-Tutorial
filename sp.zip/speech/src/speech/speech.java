package speech;

import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

public class speech {
	public static void main(String []args)
	{
		String as="alexa play music";
		speakk(as);
	}
	public static void speakk(String sp)
    {
System.setProperty("mbrola.base","mbrola");
VoiceManager vm;
Voice v;
vm=VoiceManager.getInstance();
v=vm.getVoice("mbrola_us1");

String sd="hi";
v.allocate();
v.speak(sp);    	
    }

}
